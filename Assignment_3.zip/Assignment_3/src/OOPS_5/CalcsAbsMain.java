package OOPS_5;

public class CalcsAbsMain {

	public static void main(String[] args) {
		CalcAbs1 calc = new CalcAbs1();
		calc.sum(22, 45);
		calc.sub(56, 23);
		calc.mul(12, 92);
		calc.div(84, 2);
	}
}
