package Com.OOPS_Electronics;

public class TestMain {

	public static void main(String[] args) {
		Mobile m = new Mobile();
		m.mobiledetails();

		LCD l = new LCD();
		l.lcddetails();

		Laptop la = new Laptop();
		la.laptopdetails();

	}
}
