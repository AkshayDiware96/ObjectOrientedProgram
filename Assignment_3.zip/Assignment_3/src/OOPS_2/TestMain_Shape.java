package OOPS_2;

public class TestMain_Shape {
	public static void main(String[] args) {

		Rectangle r = new Rectangle();
		r.area(10, 20, 50);

		Square s = new Square();
		s.area(0, 50, 50);

		Triangle t = new Triangle();
		t.area(10, 50, 70);

	}
}
