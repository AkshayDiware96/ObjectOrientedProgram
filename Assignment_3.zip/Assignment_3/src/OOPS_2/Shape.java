package OOPS_2;

public interface Shape {
	void area(double vertexA, double vertexB, double vertexC);
}
