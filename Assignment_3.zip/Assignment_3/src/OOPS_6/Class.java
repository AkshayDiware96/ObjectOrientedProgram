package OOPS_6;

public class Class {

	public void getNumbers(int number) {

		System.out.println("For finding 3 ,4 and numbers");
	}

}
